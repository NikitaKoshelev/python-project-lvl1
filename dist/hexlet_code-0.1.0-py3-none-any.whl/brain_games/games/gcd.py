from random import randint
import math

DESCRIPTION = "Find the greatest common divisor of given numbers"


def get_answer():
    number1 = randint(1, 50)
    number2 = randint(1, 50)
    question = "{} {}".format(number1, number2)
    answer = str(math.gcd(number1, number2))
    return question, answer
